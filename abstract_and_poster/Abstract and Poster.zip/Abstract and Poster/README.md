<strong>Important</strong><br>
<i>
Please note that the poster has 4 gifs which shows the functionality of the product.
These gifs will only play if you start the slide and view it as a full screen.
</i>



<strong>Reference of the two royalty free images:</strong>
- https://unsplash.com/photos/PdRSnDXvY-E
- https://unsplash.com/photos/tysecUm5HJA